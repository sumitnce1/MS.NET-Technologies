﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Data;

namespace EmployeeManagementSystem.Controllers
{
    public class EmployeeController : Controller
    {
        /*[Route("EmployeeList")]*/
        public IActionResult Index()
        {
            EmployeeDbContext ob = new EmployeeDbContext();
            var userlist = ob.Employee.Where(x => x.UserType != "ADMIN").ToList();
            return View(userlist);
        }
        public IActionResult Update(int Id)
        {
            EmployeeDbContext ob = new EmployeeDbContext();
            var dbempdetails = ob.Employee.FirstOrDefault(x => x.EmpId == Id);
            return View(dbempdetails);
        }
        [HttpPost]
        public IActionResult Update(Employee viewModeldetails)
        {
            EmployeeDbContext ob = new EmployeeDbContext();
            var dbempdetails = ob.Employee.FirstOrDefault(x => x.EmpId == viewModeldetails.EmpId);
            if (dbempdetails != null)
            {
                dbempdetails.Firstname = viewModeldetails.Firstname;
                dbempdetails.Lastname = viewModeldetails.Lastname;
                dbempdetails.EmployeeStatus = viewModeldetails.EmployeeStatus;
                ob.Update(dbempdetails);
                ob.SaveChanges();
                return Redirect("Index");
            }
            else
            {
                return View(dbempdetails);
            }
        }
        public IActionResult Details(int Id)
        {
            EmployeeDbContext ob = new EmployeeDbContext();
            var dbempdetails = ob.Employee.FirstOrDefault(x => x.EmpId == Id);
            return View(dbempdetails);
        }
        public IActionResult Delete(int Id)
        {
            EmployeeDbContext ob = new EmployeeDbContext();
            var dbempdetails = ob.Employee.FirstOrDefault(x => x.EmpId == Id);
            ob.Employee.Remove(dbempdetails);
            ob.SaveChanges();
            return Redirect("Index");
        }
    }
}